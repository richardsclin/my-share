const IncomingForm = require('formidable').IncomingForm;
const fs = require('fs');

module.exports = function upload(req, res) {
  const form = new IncomingForm();

  form.on('file', (field, file) => {
    // Do something with the file
    // e.g. save it to the database
    // you can access it using file.path
    console.log('file', file.name);
    console.log('file', file.path);
    const readStream = fs.createReadStream(file.path);
    fs.rename(file.path, "D:/Temp/upload/" + file.name, function(err){
      if(err){
        console.log(err.message);
      }
      console.log('done!');
     })
  });
  form.on('end', () => {
    res.json();
  });
  form.parse(req);
};
